// server setup
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var path = require('path');
var mongoose = require('mongoose');
var session = require('express-session');
var flash = require('express-flash');


app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
app.use(session({secret: 'johnahnz0rsisl33t'}));
app.use(flash());

mongoose.connect('mongodb://localhost/quoting_dojo');
mongoose.Promise = global.Promise;


// schema
var QuoteSchema = new mongoose.Schema({
	name: {type: String},
	quote: {type: String}
}, {timestamps: true});
// model
mongoose.model('Quote', QuoteSchema);
var Quote = mongoose.model('Quote');


// routes
require('./server/config/routes.js')(app);


// start server
app.listen(1337, function() {
	console.log('johnahnz0rs is listening on port 1337')
});